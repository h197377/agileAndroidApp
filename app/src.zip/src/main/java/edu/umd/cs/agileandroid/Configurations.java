package edu.umd.cs.agileandroid;

/**
 * Created by Beijie on 4/19/2017.
 */

public class Configurations {
    public static boolean REMINDER_ON = true;


}
